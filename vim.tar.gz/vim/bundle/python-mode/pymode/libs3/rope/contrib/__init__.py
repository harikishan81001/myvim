"""rope IDE tools package

This package contains modules that can be used in IDEs
but do not depend on the UI.  So these modules will be used
by `rope.ui` modules.

"""
